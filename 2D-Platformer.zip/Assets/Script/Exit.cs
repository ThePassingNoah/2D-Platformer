using UnityEngine;

public class Exit : MonoBehaviour
{
    public void EndGame() 
    {
        Application.Quit();
    }
}
